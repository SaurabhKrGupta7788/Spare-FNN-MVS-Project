=============================================================
OVERLEAF COMPILATION INSTRUCTIONS
=============================================================

This package contains all LaTeX source files for:
1. BEAMER PRESENTATION (Sparse FFN MVS Project)
2. PROJECT REPORT (SE / MVS Lab Report)

--- HOW TO COMPILE ON OVERLEAF ---

A. TO COMPILE THE BEAMER PRESENTATION (SLIDES):
   1. The default main document is already set to main.tex
      (which is a copy of Sparse_FFN_Beamer_v2.tex).
   2. Simply click 'Recompile' in Overleaf.
   3. Compiler: pdfLaTeX (default).

B. TO COMPILE THE PROJECT REPORT:
   1. Click 'Menu' (top-left of Overleaf editor).
   2. Under 'Settings', change 'Main document' from main.tex
      to 
eport_main.tex.
   3. Click 'Recompile'.
   4. The complete 30+ page project report with all figures and
      references will be generated.
=============================================================
